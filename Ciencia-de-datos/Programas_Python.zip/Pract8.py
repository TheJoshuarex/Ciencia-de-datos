# ==================================================
# PRÁCTICA 8: CLASIFICACIÓN DE INTRUSIONES
# CON KNN Y REGRESIÓN LOGÍSTICA
# ==================================================

# Librerías

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

# Configuración

np.random.seed(444)

# ==================================================
# PASO 1: SIMULACIÓN DE TRÁFICO DE RED
# ==================================================

n=400

df_red=pd.DataFrame({

'latencia':np.random.normal(
20,5,n
),

'intentos_fallidos':np.random.poisson(
1,n
),

'tamano_paquete':np.random.normal(
500,100,n
)

})

# Definir ataques

df_red['es_ataque']=np.where(

(df_red['intentos_fallidos']>2)

|

(df_red['latencia']>35),

1,

0

)

print(df_red.head())


# ==================================================
# PASO 2: REGRESIÓN LOGÍSTICA
# ==================================================

X=df_red.drop(
'es_ataque',
axis=1
)

y=df_red['es_ataque']

X_train,X_test,y_train,y_test=(

train_test_split(

X,
y,
test_size=0.2,
random_state=123

)

)

modelo_log=LogisticRegression()

modelo_log.fit(
X_train,
y_train
)

pred_log=(
modelo_log.predict(
X_test
)
)

print("\nPrecisión Regresión Logística:")

print(
accuracy_score(
y_test,
pred_log
)
)

print("\nMatriz de confusión")

print(

confusion_matrix(
y_test,
pred_log
)

)

print("\nReporte")

print(

classification_report(
y_test,
pred_log
)

)


# ==================================================
# PASO 3: KNN
# ==================================================

escalador=StandardScaler()

X_train=escalador.fit_transform(
X_train
)

X_test=escalador.transform(
X_test
)

accuracy=[]

for k in range(1,11):

    modelo_knn=KNeighborsClassifier(
        n_neighbors=k
    )

    modelo_knn.fit(
        X_train,
        y_train
    )

    pred=(
        modelo_knn.predict(
            X_test
        )
    )

    accuracy.append(

    accuracy_score(
        y_test,
        pred
    )

)

# Mejor K

mejor_k=np.argmax(
accuracy
)+1

print(
"\nMejor valor K:"
)

print(
mejor_k
)


# ==================================================
# GRÁFICA DE ACCURACY
# ==================================================

plt.figure(figsize=(8,5))

plt.plot(
range(1,11),
accuracy
)

plt.xlabel(
'Número de vecinos'
)

plt.ylabel(
'Accuracy'
)

plt.title(
'Precisión según K'
)

plt.show()


# ==================================================
# PASO 4: CLUSTERING K-MEANS
# ==================================================

datos_cluster=df_red.drop(
'es_ataque',
axis=1
)

datos_cluster=escalador.fit_transform(
datos_cluster
)

kmeans=KMeans(
n_clusters=2,
random_state=111
)

clusters=kmeans.fit_predict(
datos_cluster
)

df_red['cluster']=clusters

print(
"\nComparación:"
)

print(

pd.crosstab(
df_red['es_ataque'],
df_red['cluster']
)

)


# ==================================================
# VISUALIZACIÓN
# ==================================================

plt.figure(figsize=(10,6))

sns.scatterplot(

x='latencia',

y='intentos_fallidos',

hue='cluster',

data=df_red

)

plt.title(
'Clusters de conexiones'
)

plt.show()