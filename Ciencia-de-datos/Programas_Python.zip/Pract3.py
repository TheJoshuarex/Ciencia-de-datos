# ==========================================
# PRÁCTICA 3: ANÁLISIS DE EFICIENCIA
# EN LOGÍSTICA GLOBAL
# ==========================================

# Librerías
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import ttest_ind

# Configuración
np.random.seed(42)

# ==========================================
# Generación de datos sintéticos
# ==========================================

n = 600

tipo_transporte = np.random.choice(
    ["Terrestre","Aereo"],
    n
)

distancia_km = np.random.normal(
    800,
    300,
    n
)

# Tiempo depende de distancia y transporte
tiempo_entrega_hrs = np.where(
    tipo_transporte=="Aereo",
    distancia_km*0.01 + np.random.normal(3,2,n),
    distancia_km*0.02 + np.random.normal(5,3,n)
)

costo = np.where(
    tipo_transporte=="Aereo",
    distancia_km*4 + np.random.normal(1000,200,n),
    distancia_km*2 + np.random.normal(500,100,n)
)

# Crear DataFrame

df = pd.DataFrame({
    "distancia_km": distancia_km,
    "tiempo_entrega_hrs": tiempo_entrega_hrs,
    "tipo_transporte": tipo_transporte,
    "costo": costo
})

# Introducir valores faltantes
indices = np.random.choice(df.index,30)

df.loc[indices,'distancia_km'] = np.nan

print("Primeras filas")
print(df.head())


# ==========================================
# FASE 1: CALIDAD DE DATOS
# ==========================================

print("\nValores faltantes")

print(df.isnull().sum())

# Imputar con mediana

mediana = df["distancia_km"].median()

df["distancia_km"].fillna(
    mediana,
    inplace=True
)

print("\nValores faltantes después")

print(df.isnull().sum())


# Estadísticos descriptivos

print("\nMedia tiempo entrega")

print(
    df["tiempo_entrega_hrs"].mean()
)

print("\nDesviación estándar")

print(
    df["tiempo_entrega_hrs"].std()
)


# ==========================================
# FASE 2: RELACIÓN ENTRE VARIABLES
# ==========================================

correlacion = df["distancia_km"].corr(
    df["tiempo_entrega_hrs"]
)

print("\nCorrelación:")

print(correlacion)


# ==========================================
# FASE 3: COMPARATIVA
# ==========================================

agrupado = df.groupby(
    "tipo_transporte"
)[["tiempo_entrega_hrs","costo"]].mean()

print("\nPromedios por transporte")

print(agrupado)


# T-Test

terrestre = df[
    df["tipo_transporte"]=="Terrestre"
]["tiempo_entrega_hrs"]

aereo = df[
    df["tipo_transporte"]=="Aereo"
]["tiempo_entrega_hrs"]

t,p = ttest_ind(
    terrestre,
    aereo
)

print("\nT-statistic:",t)
print("P-value:",p)

if p<0.05:
    print("Existe diferencia significativa")
else:
    print("No existe diferencia significativa")


# ==========================================
# FASE 4: VISUALIZACIÓN
# ==========================================

# Scatter

plt.figure(figsize=(9,5))

sns.scatterplot(
    x='distancia_km',
    y='tiempo_entrega_hrs',
    hue='tipo_transporte',
    data=df
)

plt.title(
    "Distancia vs Tiempo"
)

plt.show()


# Boxplot

plt.figure(figsize=(8,5))

sns.boxplot(
    x='tipo_transporte',
    y='tiempo_entrega_hrs',
    data=df
)

plt.title(
    "Tiempo de entrega por transporte"
)

plt.show()