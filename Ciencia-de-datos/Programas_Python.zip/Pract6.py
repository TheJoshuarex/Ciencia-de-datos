# ==================================================
# PRÁCTICA 6: OPTIMIZACIÓN DE SENSORES
# EN SMART CITIES (PCA)
# ==================================================

# Librerías

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Configuración

np.random.seed(456)

# ==================================================
# PASO 1: GENERACIÓN DE DATOS
# ==================================================

n=400

datos_urbanos=pd.DataFrame({

'temp_ambiente':np.random.normal(28,4,n),

'humedad_rel':np.random.normal(60,10,n),

'densidad_vehiculos':np.random.normal(120,30,n),

'velocidad_viento':np.random.normal(15,5,n),

'radiacion_solar':np.random.normal(800,100,n),

'conteo_peatones':np.random.normal(50,15,n)

})

# Crear correlaciones y redundancia

datos_urbanos['co2_ppm']=(
datos_urbanos['densidad_vehiculos']*3.5
+
np.random.normal(300,50,n)
)

datos_urbanos['no2_ppb']=(
datos_urbanos['co2_ppm']*0.1
+
np.random.normal(5,2,n)
)

datos_urbanos['particulas_pm25']=(
datos_urbanos['co2_ppm']*0.05
+
np.random.normal(10,3,n)
)

datos_urbanos['nivel_ruido_db']=(
datos_urbanos['densidad_vehiculos']*0.2
+
50
+
np.random.normal(0,5,n)
)

print(datos_urbanos.head())


# ==================================================
# PASO 2: MATRIZ DE CORRELACIÓN
# ==================================================

plt.figure(figsize=(12,8))

sns.heatmap(
    datos_urbanos.corr(),
    annot=True,
    cmap='coolwarm'
)

plt.title(
    "Correlación de sensores urbanos"
)

plt.show()


# ==================================================
# PASO 3: ESTANDARIZACIÓN
# ==================================================

escalador=StandardScaler()

datos_escalados=escalador.fit_transform(
    datos_urbanos
)


# ==================================================
# PASO 4: PCA
# ==================================================

pca=PCA()

componentes=pca.fit_transform(
    datos_escalados
)

varianza=pca.explained_variance_ratio_

varianza_acumulada=np.cumsum(
    varianza
)

print("\nVarianza explicada")

print(varianza)

print("\nVarianza acumulada")

print(varianza_acumulada)


# ==================================================
# SCREE PLOT
# ==================================================

plt.figure(figsize=(8,5))

plt.plot(
range(
1,
len(varianza)+1
),
varianza_acumulada
)

plt.xlabel(
"Componentes"
)

plt.ylabel(
"Varianza acumulada"
)

plt.title(
"Scree Plot: Smart City"
)

plt.axhline(
y=0.85,
linestyle='--'
)

plt.show()


# ==================================================
# CANTIDAD DE COMPONENTES NECESARIOS
# ==================================================

componentes_85=np.argmax(
varianza_acumulada>=0.85
)+1

print(
"\nComponentes necesarios:"
)

print(
componentes_85
)


# ==================================================
# LOADINGS
# ==================================================

loadings=pd.DataFrame(

pca.components_.T,

columns=[
f'PC{i+1}'
for i in range(
len(datos_urbanos.columns)
)
],

index=datos_urbanos.columns

)

print("\nPesos PC1 y PC2")

print(
loadings[['PC1','PC2']]
)


# ==================================================
# BIPLOT
# ==================================================

plt.figure(figsize=(10,6))

plt.scatter(
componentes[:,0],
componentes[:,1]
)

plt.xlabel(
'PC1'
)

plt.ylabel(
'PC2'
)

plt.title(
'Mapa de Estado Urbano'
)

plt.show()