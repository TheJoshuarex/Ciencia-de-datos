# ==================================================
# PRÁCTICA 7: IMPLEMENTACIÓN DE MODELOS
# DE MACHINE LEARNING
# ==================================================

# Librerías

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score

# Configuración

np.random.seed(789)

# ==================================================
# PASO 1: GENERACIÓN DE DATOS
# ==================================================

n=500

df_empleados=pd.DataFrame({

'experiencia':np.random.normal(5,2,n),

'certificaciones':np.random.poisson(3,n),

'habilidades_sociales':np.random.uniform(1,10,n),

'remoto':np.random.choice([0,1],n)

})

# Variable objetivo salario

df_empleados['salario']=(
25000
+
(df_empleados['experiencia']*5000)
+
(df_empleados['certificaciones']*2000)
+
np.random.normal(0,3000,n)
)

# Variable objetivo retención

prob=1/(1+np.exp(

-2
+
(0.0001*df_empleados['salario'])
+
(0.2*df_empleados['habilidades_sociales'])

))

df_empleados['retencion']=np.where(
np.random.rand(n)<prob,
1,
0
)

print(df_empleados.head())


# ==================================================
# PASO 2: REGRESIÓN LINEAL
# ==================================================

X=df_empleados[
['experiencia','certificaciones']
]

y=df_empleados['salario']

X_train,X_test,y_train,y_test=(
train_test_split(
X,
y,
test_size=0.2,
random_state=123
)
)

modelo_salario=LinearRegression()

modelo_salario.fit(
X_train,
y_train
)

predicciones=modelo_salario.predict(
X_test
)

print("\nCoeficientes")

print(
modelo_salario.coef_
)

print(
"\nIntercepto"
)

print(
modelo_salario.intercept_
)

rmse=np.sqrt(
mean_squared_error(
y_test,
predicciones
)
)

print("\nRMSE")

print(rmse)


# ==================================================
# PASO 3: CLASIFICACIÓN KNN
# ==================================================

X=df_empleados[
[
'experiencia',
'habilidades_sociales',
'salario'
]
]

y=df_empleados['retencion']

X_train,X_test,y_train,y_test=(
train_test_split(
X,
y,
test_size=0.2,
random_state=123
)
)

# Escalamiento

escalador=StandardScaler()

X_train=escalador.fit_transform(
X_train
)

X_test=escalador.transform(
X_test
)

modelo_knn=KNeighborsClassifier(
n_neighbors=5
)

modelo_knn.fit(
X_train,
y_train
)

pred=(
modelo_knn.predict(
X_test
)
)

precision=accuracy_score(
y_test,
pred
)

print(
"\nPrecisión KNN:"
)

print(
precision
)


# ==================================================
# PASO 4: K-MEANS
# ==================================================

datos_cluster=df_empleados[
[
'experiencia',
'salario'
]
]

datos_cluster=escalador.fit_transform(
datos_cluster
)

kmeans=KMeans(
n_clusters=3,
random_state=456
)

clusters=kmeans.fit_predict(
datos_cluster
)

df_empleados['cluster']=clusters


# ==================================================
# VISUALIZACIÓN
# ==================================================

plt.figure(figsize=(10,6))

sns.scatterplot(
x='experiencia',
y='salario',
hue='cluster',
data=df_empleados
)

plt.title(
"Segmentación de empleados"
)

plt.show()