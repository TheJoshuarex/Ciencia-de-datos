# ==================================================
# PRÁCTICA 4: REDUCCIÓN DE DIMENSIONALIDAD
# EN MONITOREO INDUSTRIAL (PCA)
# ==================================================

# Librerías

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Configuración

np.random.seed(42)

# ==================================================
# Generación del dataset
# ==================================================

n=200

temp1=np.random.normal(100,5,n)

temp2=temp1+np.random.normal(0,1,n)

presion1=np.random.normal(50,10,n)

vibracion=(temp1*0.5)+np.random.normal(0,2,n)

datos_sensores=pd.DataFrame({

'temp_nucleo':temp1,

'temp_escape':temp2,

'presion_interna':presion1,

'vibracion_motor':vibracion,

'flujo_gas':np.random.normal(20,2,n),

'oxigeno':np.random.normal(15,1,n),

'co2':temp1*0.2+np.random.normal(0,0.5,n),

'humedad':np.random.uniform(30,40,n),

'voltaje':np.random.normal(220,2,n),

'corriente':np.random.normal(15,0.5,n),

'ruido_db':vibracion*1.2+np.random.normal(0,1,n),

'eficiencia':100-(temp1*0.1)

})

print(datos_sensores.head())


# ==================================================
# FASE 1: MATRIZ DE CORRELACIÓN
# ==================================================

plt.figure(figsize=(12,8))

sns.heatmap(
    datos_sensores.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title(
    "Matriz de correlación"
)

plt.show()


# ==================================================
# FASE 2: ESTANDARIZACIÓN
# ==================================================

escalador=StandardScaler()

datos_escalados=escalador.fit_transform(
    datos_sensores
)


# ==================================================
# FASE 3: EJECUCIÓN PCA
# ==================================================

pca=PCA()

componentes=pca.fit_transform(
    datos_escalados
)

# Varianza explicada

varianza=pca.explained_variance_ratio_

varianza_acumulada=np.cumsum(
    varianza
)

print("\nVarianza explicada:")

print(varianza)

print("\nVarianza acumulada:")

print(varianza_acumulada)


# ==================================================
# SCREE PLOT
# ==================================================

plt.figure(figsize=(8,5))

plt.plot(
    range(1,len(varianza)+1),
    varianza_acumulada
)

plt.axhline(
    y=0.85,
    linestyle="--"
)

plt.xlabel(
    "Número de componentes"
)

plt.ylabel(
    "Varianza acumulada"
)

plt.title(
    "Scree Plot"
)

plt.show()


# ==================================================
# COMPONENTES NECESARIOS PARA 85%
# ==================================================

componentes_85=np.argmax(
    varianza_acumulada>=0.85
)+1

print("\nComponentes necesarios:")

print(componentes_85)


# ==================================================
# LOADINGS
# ==================================================

loadings=pd.DataFrame(

pca.components_.T,

columns=[
f'PC{i+1}'
for i in range(
len(datos_sensores.columns)
)
],

index=datos_sensores.columns

)

print("\nLoadings PC1 y PC2")

print(
loadings[['PC1','PC2']]
)


# ==================================================
# BIPLOT
# ==================================================

plt.figure(figsize=(10,6))

plt.scatter(
    componentes[:,0],
    componentes[:,1]
)

plt.xlabel("PC1")

plt.ylabel("PC2")

plt.title(
    "Biplot PCA"
)

plt.show()