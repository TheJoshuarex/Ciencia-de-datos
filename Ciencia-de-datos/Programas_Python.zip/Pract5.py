# ==================================================
# PRÁCTICA 5: REDUCCIÓN DE DIMENSIONES
# EN TRÁFICO DE RED (PCA)
# ==================================================

# Librerías

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Configuración

np.random.seed(123)

# ==================================================
# PASO 1: GENERACIÓN DE DATOS
# ==================================================

n=300

datos_red=pd.DataFrame({

'duracion_ms':np.random.normal(50,10,n),

'paquetes_enviados':np.random.normal(100,20,n),

'errores_checksum':np.random.poisson(2,n),

'latencia_avg':np.random.normal(15,5,n),

'jitter':np.random.normal(2,0.5,n),

'uso_memoria_sw':np.random.normal(40,10,n),

'peticiones_http':np.random.normal(200,50,n)

})

# Dependencias (redundancia)

datos_red['bytes_enviados']=(
datos_red['paquetes_enviados']*1500
+
np.random.normal(0,500,n)
)

datos_red['reintentos_tcp']=(
datos_red['errores_checksum']*1.5
+
np.random.normal(0,0.5,n)
)

datos_red['carga_cpu_router']=(
(datos_red['paquetes_enviados']*0.4)
+
(datos_red['latencia_avg']*0.2)
)

print(datos_red.head())


# ==================================================
# PASO 2: MATRIZ DE CORRELACIÓN
# ==================================================

plt.figure(figsize=(12,8))

sns.heatmap(
    datos_red.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title(
    "Correlación entre métricas de red"
)

plt.show()


# ==================================================
# PASO 3: ESTANDARIZACIÓN
# ==================================================

escalador=StandardScaler()

datos_escalados=escalador.fit_transform(
    datos_red
)


# ==================================================
# PASO 4: PCA
# ==================================================

pca=PCA()

componentes=pca.fit_transform(
    datos_escalados
)

varianza=pca.explained_variance_ratio_

varianza_acumulada=np.cumsum(
    varianza
)

print("\nVarianza explicada")

print(varianza)

print("\nVarianza acumulada")

print(varianza_acumulada)


# ==================================================
# SCREE PLOT
# ==================================================

plt.figure(figsize=(8,5))

plt.plot(
range(
1,
len(varianza)+1
),
varianza_acumulada
)

plt.xlabel(
"Componentes"
)

plt.ylabel(
"Varianza acumulada"
)

plt.title(
"Scree Plot: Tráfico de Red"
)

plt.axhline(
y=0.70,
linestyle='--'
)

plt.show()


# ==================================================
# LOADINGS
# ==================================================

loadings=pd.DataFrame(

pca.components_.T,

columns=[
f'PC{i+1}'
for i in range(
len(datos_red.columns)
)
],

index=datos_red.columns

)

print("\nPesos PC1 y PC2")

print(
loadings[['PC1','PC2']]
)


# ==================================================
# BIPLOT
# ==================================================

plt.figure(figsize=(10,6))

plt.scatter(
componentes[:,0],
componentes[:,1]
)

plt.xlabel(
'PC1'
)

plt.ylabel(
'PC2'
)

plt.title(
'Mapa de Estado de Red'
)

plt.show()