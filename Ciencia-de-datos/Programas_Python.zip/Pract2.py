# ==========================================
# PRÁCTICA 2: ANÁLISIS DE CALIDAD INDUSTRIAL
# ==========================================

# Librerías
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Configuración
np.random.seed(42)

# ==========================================
# Generación de datos sintéticos
# ==========================================

n = 500

temperatura = np.random.normal(80, 5, n)
presion = np.random.normal(50, 8, n)
turno = np.random.choice(["Matutino", "Vespertino"], n)

# Relación entre temperatura y errores
tasa_error = (temperatura * 0.15) + np.random.normal(0,2,n)

# Crear DataFrame
df = pd.DataFrame({
    'temperatura': temperatura,
    'presion': presion,
    'turno': turno,
    'tasa_error': tasa_error
})

# Introducir algunos valores faltantes
indices = np.random.choice(df.index,20)
df.loc[indices,'temperatura'] = np.nan

print("Primeras filas")
print(df.head())

# ==========================================
# FASE A: ANÁLISIS EXPLORATORIO
# ==========================================

print("\nMedia:")
print(df['temperatura'].mean())

print("\nMediana:")
print(df['temperatura'].median())

print("\nDesviación estándar:")
print(df['temperatura'].std())

# Valores faltantes
print("\nValores faltantes:")
print(df.isnull().sum())

# Limpiar usando media
media_temp = df['temperatura'].mean()
df['temperatura'].fillna(media_temp,inplace=True)

print("\nValores faltantes después de limpieza:")
print(df.isnull().sum())

# Correlación Pearson
correlacion = df['temperatura'].corr(df['tasa_error'])

print("\nCorrelación temperatura vs tasa error:")
print(correlacion)

# ==========================================
# FASE B: AGRUPACIÓN
# ==========================================

promedio_turno = df.groupby("turno")["tasa_error"].mean()

print("\nPromedio de errores por turno")
print(promedio_turno)

temperatura_turno = df.groupby("turno")["temperatura"].mean()

print("\nTemperatura promedio por turno")
print(temperatura_turno)

# ==========================================
# FASE C: VISUALIZACIÓN
# ==========================================

# Boxplot

plt.figure(figsize=(8,5))

sns.boxplot(
    x='turno',
    y='tasa_error',
    data=df
)

plt.title("Errores por turno")
plt.show()

# Scatter con línea de regresión

plt.figure(figsize=(8,5))

sns.regplot(
    x='temperatura',
    y='tasa_error',
    data=df
)

plt.title("Temperatura vs Tasa de error")
plt.show()